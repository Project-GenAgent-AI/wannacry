
void Unwind@0040795b(void)

{
  int unaff_EBP;
  
  FUN_0040181b((undefined4 *)(*(int *)(unaff_EBP + -0x10) + 0x2c));
  return;
}
