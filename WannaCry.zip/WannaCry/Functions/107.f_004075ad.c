
void FUN_004075ad(void)

{
  FUN_004074a4();
  return;
}
