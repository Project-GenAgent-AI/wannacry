
void __cdecl FUN_004056dd(undefined4 param_1,size_t param_2,size_t param_3)

{
  calloc(param_2,param_3);
  return;
}
