
void __cdecl FUN_00401225(int param_1)

{
  size_t sVar1;
  int iVar2;
  int iVar3;
  uint _Seed;
  int iVar4;
  undefined4 *puVar5;
  WCHAR *pWVar6;
  int iVar7;
  WCHAR local_19c;
  undefined4 local_19a [99];
  DWORD local_c;
  uint local_8;
  
  local_19c = DAT_0040f874;
  local_c = 399;
  puVar5 = local_19a;
  for (iVar3 = 99; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar5 = 0;
    puVar5 = puVar5 + 1;
  }
  *(undefined2 *)puVar5 = 0;
  GetComputerNameW(&local_19c,&local_c);
  local_8 = 0;
  _Seed = 1;
  sVar1 = wcslen(&local_19c);
  if (sVar1 != 0) {
    pWVar6 = &local_19c;
    do {
      _Seed = _Seed * (ushort)*pWVar6;
      local_8 = local_8 + 1;
      pWVar6 = pWVar6 + 1;
      sVar1 = wcslen(&local_19c);
    } while (local_8 < sVar1);
  }
  srand(_Seed);
  iVar3 = rand();
  iVar7 = 0;
  iVar4 = iVar3 % 8 + 8;
  if (0 < iVar4) {
    do {
      iVar2 = rand();
      *(char *)(iVar7 + param_1) = (char)(iVar2 % 0x1a) + 'a';
      iVar7 = iVar7 + 1;
    } while (iVar7 < iVar4);
  }
  for (; iVar7 < iVar3 % 8 + 0xb; iVar7 = iVar7 + 1) {
    iVar4 = rand();
    *(char *)(iVar7 + param_1) = (char)(iVar4 % 10) + '0';
  }
  *(undefined1 *)(iVar7 + param_1) = 0;
  return;
}
