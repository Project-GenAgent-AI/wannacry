
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_00401a45(void)

{
  HMODULE hModule;
  undefined4 uVar1;
  
  if (DAT_0040f894 == (FARPROC)0x0) {
    hModule = LoadLibraryA(s_advapi32.dll_0040e020);
    if (hModule != (HMODULE)0x0) {
      DAT_0040f894 = GetProcAddress(hModule,s_CryptAcquireContextA_0040f110);
      DAT_0040f898 = GetProcAddress(hModule,s_CryptImportKey_0040f100);
      DAT_0040f89c = GetProcAddress(hModule,s_CryptDestroyKey_0040f0f0);
      DAT_0040f8a0 = GetProcAddress(hModule,s_CryptEncrypt_0040f0e0);
      DAT_0040f8a4 = GetProcAddress(hModule,s_CryptDecrypt_0040f0d0);
      _DAT_0040f8a8 = GetProcAddress(hModule,s_CryptGenKey_0040f0c4);
      if ((((DAT_0040f894 != (FARPROC)0x0) && (DAT_0040f898 != (FARPROC)0x0)) &&
          (DAT_0040f89c != (FARPROC)0x0)) &&
         (((DAT_0040f8a0 != (FARPROC)0x0 && (DAT_0040f8a4 != (FARPROC)0x0)) &&
          (_DAT_0040f8a8 != (FARPROC)0x0)))) goto LAB_00401aec;
    }
    uVar1 = 0;
  }
  else {
LAB_00401aec:
    uVar1 = 1;
  }
  return uVar1;
}
