
void __fastcall FUN_0040181b(undefined4 *param_1)

{
  *param_1 = &PTR_FUN_004081ec;
  DeleteCriticalSection((LPCRITICAL_SECTION)(param_1 + 4));
  return;
}
