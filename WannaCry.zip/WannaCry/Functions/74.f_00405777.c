
/* WARNING: Removing unreachable block (ram,0x00405836) */

undefined4 __cdecl FUN_00405777(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  
  if (param_1 == 0) {
    uVar3 = 0xfffffffe;
  }
  else {
    *(undefined4 *)(param_1 + 0x18) = 0;
    if (*(int *)(param_1 + 0x20) == 0) {
      *(code **)(param_1 + 0x20) = FUN_004056dd;
      *(undefined4 *)(param_1 + 0x28) = 0;
    }
    if (*(int *)(param_1 + 0x24) == 0) {
      *(undefined1 **)(param_1 + 0x24) = &LAB_004056ee;
    }
    iVar1 = (**(code **)(param_1 + 0x20))(*(undefined4 *)(param_1 + 0x28),1,0x18);
    *(int *)(param_1 + 0x1c) = iVar1;
    if (iVar1 != 0) {
      *(undefined4 *)(iVar1 + 0x14) = 0;
      *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0xc) = 0;
      *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0xc) = 1;
      *(undefined4 *)(*(int *)(param_1 + 0x1c) + 0x10) = 0xf;
      piVar2 = FUN_0040432b(param_1,~-(uint)(*(int *)(*(int *)(param_1 + 0x1c) + 0xc) != 0) &
                                    0x4055c4,0x8000);
      *(int **)(*(int *)(param_1 + 0x1c) + 0x14) = piVar2;
      if (*(int *)(*(int *)(param_1 + 0x1c) + 0x14) != 0) {
        FUN_004056fa(param_1);
        return 0;
      }
      FUN_00405739(param_1);
    }
    uVar3 = 0xfffffffc;
  }
  return uVar3;
}
