
void __thiscall FUN_00403797(void *this,byte *param_1,byte *param_2)

{
  uint *puVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint *puVar5;
  byte *pbVar6;
  exception local_38 [12];
  uint local_2c;
  int local_28;
  int local_24;
  int local_20;
  byte *local_1c;
  int local_18;
  int local_14;
  int local_10;
  uint *local_c;
  uint *local_8;
  
  if (*(char *)((int)this + 4) == '\0') {
    exception::exception(local_38,&this_0040f570);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_38,(ThrowInfo *)&pThrowInfo_0040d570);
  }
  if (*(int *)((int)this + 0x3cc) == 0x10) {
    FUN_004031bc(this,param_1,param_2);
  }
  else {
    iVar3 = *(int *)((int)this + 0x3cc) / 4;
    iVar4 = (-(uint)(iVar3 != 4) & (iVar3 != 6) + 1) * 0x20;
    local_1c = *(byte **)(&DAT_0040bc28 + iVar4);
    local_18 = *(int *)(&DAT_0040bc30 + iVar4);
    local_20 = *(int *)(&DAT_0040bc38 + iVar4);
    if (0 < iVar3) {
      puVar5 = (uint *)((int)this + 0x454);
      local_10 = iVar3;
      local_8 = (uint *)((int)this + 0x1e8);
      do {
        *puVar5 = (uint)*param_1 << 0x18;
        *puVar5 = *puVar5 | (uint)param_1[1] << 0x10;
        *puVar5 = *puVar5 | (uint)param_1[2] << 8;
        *puVar5 = *puVar5 | (uint)param_1[3];
        puVar1 = local_8 + 1;
        param_1 = param_1 + 4;
        *puVar5 = *puVar5 ^ *local_8;
        local_10 = local_10 + -1;
        puVar5 = puVar5 + 1;
        local_8 = puVar1;
      } while (local_10 != 0);
    }
    local_10 = 1;
    if (1 < *(int *)((int)this + 0x410)) {
      local_c = (uint *)((int)this + 0x208);
      do {
        if (0 < iVar3) {
          local_8 = local_c;
          local_24 = local_18 - (int)local_1c;
          param_1 = local_1c;
          local_28 = local_20 - (int)local_1c;
          puVar5 = (uint *)((int)this + 0x434);
          local_14 = iVar3;
          do {
            local_2c = (uint)*(byte *)((int)this + ((int)(param_1 + local_24) % iVar3) * 4 + 0x455);
            puVar1 = local_8 + 1;
            *puVar5 = *(uint *)(&DAT_0040a3fc + local_2c * 4) ^
                      *(uint *)(&DAT_0040a7fc +
                               (*(uint *)((int)this +
                                         ((int)(param_1 + local_28) % iVar3) * 4 + 0x454) & 0xff) *
                               4) ^
                      *(uint *)(&DAT_00409ffc +
                               (uint)*(byte *)((int)this + ((int)param_1 % iVar3) * 4 + 0x456) * 4)
                      ^ *(uint *)(&DAT_00409bfc + (uint)*(byte *)((int)puVar5 + 0x23) * 4) ^
                      *local_8;
            puVar5 = puVar5 + 1;
            param_1 = param_1 + 1;
            local_14 = local_14 + -1;
            local_8 = puVar1;
          } while (local_14 != 0);
        }
        memcpy((void *)((int)this + 0x454),(void *)((int)this + 0x434),iVar3 << 2);
        local_c = local_c + 8;
        local_10 = local_10 + 1;
      } while (local_10 < *(int *)((int)this + 0x410));
    }
    local_8 = (uint *)0x0;
    if (0 < iVar3) {
      pbVar6 = param_2;
      iVar4 = local_18;
      param_2 = (byte *)((int)this + 0x454);
      do {
        uVar2 = *(undefined4 *)
                 ((int)this + ((int)local_8 + *(int *)((int)this + 0x410) * 8) * 4 + 0x1e8);
        *pbVar6 = (&DAT_00408afc)[param_2[3]] ^ (byte)((uint)uVar2 >> 0x18);
        pbVar6[1] = (&DAT_00408afc)
                    [*(byte *)((int)this +
                              ((int)(local_1c + (iVar4 - local_18)) % iVar3) * 4 + 0x456)] ^
                    (byte)((uint)uVar2 >> 0x10);
        pbVar6[2] = (&DAT_00408afc)[*(byte *)((int)this + (iVar4 % iVar3) * 4 + 0x455)] ^
                    (byte)((uint)uVar2 >> 8);
        param_1._0_1_ = (byte)uVar2;
        pbVar6[3] = (&DAT_00408afc)
                    [*(uint *)((int)this + (((local_20 - local_18) + iVar4) % iVar3) * 4 + 0x454) &
                     0xff] ^ (byte)param_1;
        pbVar6 = pbVar6 + 4;
        local_8 = (uint *)((int)local_8 + 1);
        iVar4 = iVar4 + 1;
        param_2 = param_2 + 4;
      } while ((int)local_8 < iVar3);
    }
  }
  return;
}
