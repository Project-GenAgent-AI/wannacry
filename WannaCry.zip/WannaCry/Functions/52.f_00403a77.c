
void __thiscall FUN_00403a77(void *this,byte *param_1,byte *param_2,uint param_3,uint param_4)

{
  uint uVar1;
  bool bVar2;
  exception local_10 [12];
  
  if (*(char *)((int)this + 4) == '\0') {
    exception::exception(local_10,&this_0040f570);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_10,(ThrowInfo *)&pThrowInfo_0040d570);
  }
  if (param_3 != 0) {
    uVar1 = *(uint *)((int)this + 0x3cc);
    if ((int)((ulonglong)param_3 % (ulonglong)uVar1) == 0) {
      if (param_4 == 1) {
        param_4 = 0;
        if ((int)(((ulonglong)param_3 % (ulonglong)uVar1 << 0x20 | (ulonglong)param_3) /
                 (ulonglong)uVar1) != 0) {
          do {
            FUN_00403797(this,param_1,param_2);
            FUN_00403a28(this,param_2,(byte *)((int)this + 0x3f0));
            memcpy((void *)((int)this + 0x3f0),param_1,*(size_t *)((int)this + 0x3cc));
            uVar1 = *(uint *)((int)this + 0x3cc);
            param_1 = param_1 + uVar1;
            param_2 = param_2 + uVar1;
            param_4 = param_4 + 1;
          } while (param_4 < param_3 / uVar1);
        }
      }
      else {
        bVar2 = param_4 == 2;
        param_4 = 0;
        if (bVar2) {
          if (param_3 / uVar1 != 0) {
            do {
              FUN_0040350f(this,(uint *)((int)this + 0x3f0),param_2);
              FUN_00403a28(this,param_2,param_1);
              memcpy((void *)((int)this + 0x3f0),param_1,*(size_t *)((int)this + 0x3cc));
              uVar1 = *(uint *)((int)this + 0x3cc);
              param_1 = param_1 + uVar1;
              param_2 = param_2 + uVar1;
              param_4 = param_4 + 1;
            } while (param_4 < param_3 / uVar1);
          }
        }
        else if (param_3 / uVar1 != 0) {
          do {
            FUN_00403797(this,param_1,param_2);
            uVar1 = *(uint *)((int)this + 0x3cc);
            param_1 = param_1 + uVar1;
            param_2 = param_2 + uVar1;
            param_4 = param_4 + 1;
          } while (param_4 < param_3 / uVar1);
        }
      }
      return;
    }
  }
  exception::exception(local_10,&PTR_DAT_0040f574);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_10,(ThrowInfo *)&pThrowInfo_0040d570);
}
