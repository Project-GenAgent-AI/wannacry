
int __cdecl FUN_0040657a(undefined4 *param_1,int *param_2,int *param_3,int *param_4)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  int local_10;
  int local_c;
  int local_8;
  
  piVar3 = param_2;
  puVar2 = param_1;
  iVar5 = 0;
  *param_2 = 0;
  *param_3 = 0;
  *param_4 = 0;
  iVar4 = FUN_00405d0e((char *)*param_1,param_1[3] + param_1[0x1e],0);
  if (iVar4 == 0) {
    iVar4 = FUN_00405e6b((char *)*puVar2,&local_c);
    if (iVar4 == 0) {
      if (local_c != 0x4034b50) {
        iVar5 = -0x67;
      }
    }
    else {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e27((char *)*puVar2,(int *)&param_2);
    if (iVar4 != 0) {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e27((char *)*puVar2,(int *)&param_1);
    if (iVar4 != 0) {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e27((char *)*puVar2,(int *)&param_2);
    if (iVar4 == 0) {
      if ((iVar5 == 0) &&
         ((piVar1 = (int *)puVar2[0xd], param_2 != piVar1 ||
          ((piVar1 != (int *)0x0 && (piVar1 != (int *)0x8)))))) {
        iVar5 = -0x67;
      }
    }
    else {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e6b((char *)*puVar2,(int *)&param_2);
    if (iVar4 != 0) {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e6b((char *)*puVar2,(int *)&param_2);
    if (iVar4 == 0) {
      if (((iVar5 == 0) && (param_2 != (int *)puVar2[0xf])) && (((uint)param_1 & 8) == 0)) {
        iVar5 = -0x67;
      }
    }
    else {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e6b((char *)*puVar2,(int *)&param_2);
    if (iVar4 == 0) {
      if (((iVar5 == 0) && (param_2 != (int *)puVar2[0x10])) && (((uint)param_1 & 8) == 0)) {
        iVar5 = -0x67;
      }
    }
    else {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e6b((char *)*puVar2,(int *)&param_2);
    if (iVar4 == 0) {
      if (((iVar5 == 0) && (param_2 != (int *)puVar2[0x11])) && (((uint)param_1 & 8) == 0)) {
        iVar5 = -0x67;
      }
    }
    else {
      iVar5 = -1;
    }
    iVar4 = FUN_00405e27((char *)*puVar2,&local_8);
    if (iVar4 == 0) {
      if ((iVar5 == 0) && (local_8 != puVar2[0x12])) {
        iVar5 = -0x67;
      }
    }
    else {
      iVar5 = -1;
    }
    *piVar3 = *piVar3 + local_8;
    iVar4 = FUN_00405e27((char *)*puVar2,&local_10);
    if (iVar4 != 0) {
      iVar5 = -1;
    }
    *param_3 = puVar2[0x1e] + 0x1e + local_8;
    *param_4 = local_10;
    *piVar3 = *piVar3 + local_10;
  }
  else {
    iVar5 = -1;
  }
  return iVar5;
}
