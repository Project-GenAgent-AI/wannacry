
bool __cdecl FUN_00401b5f(wchar_t *param_1)

{
  DWORD DVar1;
  wchar_t *pwVar2;
  int iVar3;
  undefined4 *puVar4;
  WCHAR local_2d4;
  undefined4 local_2d2 [129];
  WCHAR local_cc;
  undefined4 local_ca [49];
  
  puVar4 = (undefined4 *)&stack0xfffffb26;
  for (iVar3 = 0x81; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  *(undefined2 *)puVar4 = 0;
  local_2d4 = DAT_0040f874;
  puVar4 = local_2d2;
  for (iVar3 = 0x81; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  *(undefined2 *)puVar4 = 0;
  local_cc = DAT_0040f874;
  puVar4 = local_ca;
  for (iVar3 = 0x31; iVar3 != 0; iVar3 = iVar3 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  *(undefined2 *)puVar4 = 0;
  MultiByteToWideChar(0,0,(LPCSTR)&lpMultiByteStr_0040f8ac,-1,&local_cc,99);
  GetWindowsDirectoryW((LPWSTR)&stack0xfffffb24,0x104);
  swprintf(&local_2d4,0x40f40c,(wchar_t *)&stack0xfffffb24);
  DVar1 = GetFileAttributesW(&local_2d4);
  if ((DVar1 == 0xffffffff) || (iVar3 = FUN_00401af6(&local_2d4,&local_cc,param_1), iVar3 == 0)) {
    swprintf(&local_2d4,0x40f3f8,(wchar_t *)&stack0xfffffb24);
    iVar3 = FUN_00401af6(&local_2d4,&local_cc,param_1);
    if ((iVar3 == 0) &&
       (iVar3 = FUN_00401af6((LPCWSTR)&stack0xfffffb24,&local_cc,param_1), iVar3 == 0)) {
      GetTempPathW(0x104,&local_2d4);
      pwVar2 = wcsrchr(&local_2d4,L'\\');
      if (pwVar2 != (wchar_t *)0x0) {
        pwVar2 = wcsrchr(&local_2d4,L'\\');
        *pwVar2 = L'\0';
      }
      iVar3 = FUN_00401af6(&local_2d4,&local_cc,param_1);
      return iVar3 != 0;
    }
  }
  return true;
}
