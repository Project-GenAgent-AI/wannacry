
longlong __cdecl FUN_00406b02(uint param_1)

{
  longlong lVar1;
  
  lVar1 = __allmul(param_1 + 0xb6109100,((int)param_1 >> 0x1f) + 2 + (uint)(0x49ef6eff < param_1),
                   10000000,0);
  return lVar1;
}
