
int __cdecl FUN_00403bd6(int param_1,void *param_2,int param_3)

{
  void *_Src;
  uint uVar1;
  void *pvVar2;
  undefined4 uVar3;
  void *pvVar4;
  uint uVar5;
  undefined4 local_8;
  
  pvVar2 = param_2;
  _Src = *(void **)(param_1 + 0x30);
  pvVar4 = *(void **)(param_1 + 0x34);
  local_8 = *(void **)((int)param_2 + 0xc);
  if (pvVar4 < _Src) {
    pvVar4 = *(void **)(param_1 + 0x2c);
  }
  uVar1 = *(uint *)((int)param_2 + 0x10);
  uVar5 = (int)pvVar4 - (int)_Src;
  if (uVar1 < (uint)((int)pvVar4 - (int)_Src)) {
    uVar5 = uVar1;
  }
  if ((uVar5 != 0) && (param_3 == -5)) {
    param_3 = 0;
  }
  *(int *)((int)param_2 + 0x14) = *(int *)((int)param_2 + 0x14) + uVar5;
  *(uint *)((int)param_2 + 0x10) = uVar1 - uVar5;
  if (*(code **)(param_1 + 0x38) != (code *)0x0) {
    uVar3 = (**(code **)(param_1 + 0x38))(*(undefined4 *)(param_1 + 0x3c),_Src,uVar5);
    *(undefined4 *)(param_1 + 0x3c) = uVar3;
    *(undefined4 *)((int)param_2 + 0x30) = uVar3;
  }
  param_2 = _Src;
  if (uVar5 != 0) {
    memcpy(local_8,_Src,uVar5);
    local_8 = (void *)((int)local_8 + uVar5);
    param_2 = (void *)((int)_Src + uVar5);
  }
  if (param_2 == *(void **)(param_1 + 0x2c)) {
    param_2 = *(void **)(param_1 + 0x28);
    if (*(void **)(param_1 + 0x34) == *(void **)(param_1 + 0x2c)) {
      *(void **)(param_1 + 0x34) = param_2;
    }
    uVar1 = *(uint *)((int)pvVar2 + 0x10);
    uVar5 = *(int *)(param_1 + 0x34) - (int)param_2;
    if (uVar1 < uVar5) {
      uVar5 = uVar1;
    }
    if ((uVar5 != 0) && (param_3 == -5)) {
      param_3 = 0;
    }
    *(int *)((int)pvVar2 + 0x14) = *(int *)((int)pvVar2 + 0x14) + uVar5;
    *(uint *)((int)pvVar2 + 0x10) = uVar1 - uVar5;
    if (*(code **)(param_1 + 0x38) != (code *)0x0) {
      uVar3 = (**(code **)(param_1 + 0x38))(*(undefined4 *)(param_1 + 0x3c),param_2,uVar5);
      *(undefined4 *)(param_1 + 0x3c) = uVar3;
      *(undefined4 *)((int)pvVar2 + 0x30) = uVar3;
    }
    if (uVar5 != 0) {
      memcpy(local_8,param_2,uVar5);
      local_8 = (void *)((int)local_8 + uVar5);
      param_2 = (void *)((int)param_2 + uVar5);
    }
  }
  *(void **)((int)pvVar2 + 0xc) = local_8;
  *(void **)(param_1 + 0x30) = param_2;
  return param_3;
}
