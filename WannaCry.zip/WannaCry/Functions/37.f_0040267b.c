
bool __cdecl FUN_0040267b(int *param_1,int *param_2)

{
  uint dwSize;
  uint uVar1;
  BOOL BVar2;
  uint flNewProtect;
  bool bVar3;
  
  dwSize = param_2[2];
  if (dwSize == 0) {
    bVar3 = true;
  }
  else {
    uVar1 = param_2[3];
    if ((uVar1 & 0x2000000) == 0) {
      flNewProtect = *(uint *)(&DAT_0040f53c +
                              (((uVar1 >> 0x1e & 1) + (uVar1 >> 0x1d & 1) * 2) * 2 -
                              ((int)uVar1 >> 0x1f)) * 4);
      if ((uVar1 & 0x4000000) != 0) {
        flNewProtect = flNewProtect | 0x200;
      }
      BVar2 = VirtualProtect((LPVOID)*param_2,dwSize,flNewProtect,(PDWORD)&param_2);
      bVar3 = BVar2 != 0;
    }
    else {
      if ((*param_2 == param_2[1]) &&
         (((param_2[4] != 0 || (*(uint *)(*param_1 + 0x38) == param_1[0xe])) ||
          (dwSize % (uint)param_1[0xe] == 0)))) {
        (*(code *)param_1[8])(*param_2,dwSize,0x4000,param_1[0xc]);
      }
      bVar3 = true;
    }
  }
  return bVar3;
}
