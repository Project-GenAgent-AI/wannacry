
void __fastcall FUN_00402a46(undefined4 *param_1)

{
  *(undefined1 *)(param_1 + 1) = 0;
  *param_1 = &PTR_FUN_0040bc7c;
  return;
}
