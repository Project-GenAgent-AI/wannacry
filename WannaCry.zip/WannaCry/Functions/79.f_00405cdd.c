
int __cdecl FUN_00405cdd(char *param_1)

{
  DWORD DVar1;
  
  if (*param_1 != '\0') {
    if (param_1[1] != '\0') {
      DVar1 = SetFilePointer(*(HANDLE *)(param_1 + 4),0,(PLONG)0x0,1);
      return DVar1 - *(int *)(param_1 + 0xc);
    }
    if (*param_1 != '\0') {
      return 0;
    }
  }
  return *(int *)(param_1 + 0x1c);
}
