
uint __cdecl FUN_00406880(uint param_1,int param_2,uint param_3,undefined1 *param_4)

{
  int *piVar1;
  char cVar2;
  int *piVar3;
  byte *pbVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint local_c;
  uint local_8;
  
  local_c = 0;
  local_8 = 0;
  if (param_4 != (undefined1 *)0x0) {
    *param_4 = 0;
  }
  if ((param_1 == 0) || (piVar3 = *(int **)(param_1 + 0x7c), piVar3 == (int *)0x0)) {
    local_8 = 0xffffff9a;
  }
  else if (*piVar3 == 0) {
    local_8 = 0xffffff9c;
  }
  else if (param_3 == 0) {
LAB_00406a75:
    local_8 = 0;
  }
  else {
    piVar3[5] = param_3;
    piVar3[4] = param_2;
    if ((uint)piVar3[0x17] < param_3) {
      piVar3[5] = piVar3[0x17];
    }
    if (piVar3[5] != 0) {
      do {
        if ((piVar3[2] == 0) && (uVar7 = piVar3[0x16], uVar7 != 0)) {
          uVar8 = 0x4000;
          if ((uVar7 < 0x4000) && (uVar8 = uVar7, uVar7 == 0)) {
            if (param_4 != (undefined1 *)0x0) {
              *param_4 = 1;
            }
            goto LAB_00406a75;
          }
          iVar6 = FUN_00405d0e((char *)piVar3[0x18],piVar3[0x1a] + piVar3[0xf],0);
          if ((iVar6 != 0) ||
             (uVar7 = FUN_00405d8a((void *)*piVar3,uVar8,1,(char *)piVar3[0x18]), uVar7 != 1)) {
            return 0xffffffff;
          }
          piVar3[0xf] = piVar3[0xf] + uVar8;
          piVar3[0x16] = piVar3[0x16] - uVar8;
          iVar6 = *piVar3;
          piVar3[1] = iVar6;
          piVar3[2] = uVar8;
          if (((char)piVar3[0x1b] != '\0') && (param_1 = 0, uVar8 != 0)) {
            do {
              bVar5 = FUN_004055a3((uint *)(piVar3 + 0x1c),*(byte *)(param_1 + iVar6));
              uVar7 = param_1 + 1;
              *(byte *)(param_1 + iVar6) = bVar5;
              param_1 = uVar7;
            } while (uVar7 < uVar8);
          }
        }
        uVar7 = piVar3[2];
        uVar8 = piVar3[0x1f];
        if (uVar7 < (uint)piVar3[0x1f]) {
          uVar8 = uVar7;
        }
        if (uVar8 != 0) {
          cVar2 = *(char *)(piVar3[1] + -1 + uVar8);
          piVar1 = piVar3 + 0x1f;
          *piVar1 = *piVar1 - uVar8;
          piVar3[2] = uVar7 - uVar8;
          piVar3[1] = piVar3[1] + uVar8;
          if ((*piVar1 == 0) && (cVar2 != (char)piVar3[0x20])) {
            return 0xffffff96;
          }
        }
        if (piVar3[0x19] == 0) {
          uVar7 = piVar3[2];
          if ((uint)piVar3[5] < (uint)piVar3[2]) {
            uVar7 = piVar3[5];
          }
          uVar8 = 0;
          if (uVar7 != 0) {
            do {
              *(undefined1 *)(piVar3[4] + uVar8) = *(undefined1 *)(piVar3[1] + uVar8);
              uVar8 = uVar8 + 1;
            } while (uVar8 < uVar7);
          }
          uVar8 = FUN_0040541f(piVar3[0x14],(byte *)piVar3[4],uVar7);
          piVar3[0x17] = piVar3[0x17] - uVar7;
          piVar3[2] = piVar3[2] - uVar7;
          piVar3[5] = piVar3[5] - uVar7;
          piVar3[4] = piVar3[4] + uVar7;
          piVar3[1] = piVar3[1] + uVar7;
          piVar3[6] = piVar3[6] + uVar7;
          local_8 = local_8 + uVar7;
          piVar3[0x14] = uVar8;
          if ((piVar3[0x17] == 0) && (param_4 != (undefined1 *)0x0)) {
            *param_4 = 1;
          }
        }
        else {
          pbVar4 = (byte *)piVar3[4];
          iVar6 = piVar3[6];
          local_c = FUN_0040583c(piVar3 + 1,2);
          uVar8 = piVar3[6] - iVar6;
          uVar7 = FUN_0040541f(piVar3[0x14],pbVar4,uVar8);
          piVar3[0x17] = piVar3[0x17] - uVar8;
          local_8 = local_8 + uVar8;
          piVar3[0x14] = uVar7;
          if ((local_c == 1) || (piVar3[0x17] == 0)) {
            if (param_4 == (undefined1 *)0x0) {
              return local_8;
            }
            *param_4 = 1;
            return local_8;
          }
          if (local_c != 0) {
            return local_c;
          }
        }
      } while (piVar3[5] != 0);
      if (local_c != 0) {
        return local_c;
      }
    }
  }
  return local_8;
}
