
void __thiscall FUN_00403a28(void *this,byte *param_1,byte *param_2)

{
  int iVar1;
  exception local_10 [12];
  
  if (*(char *)((int)this + 4) != '\0') {
    iVar1 = 0;
    if (0 < *(int *)((int)this + 0x3cc)) {
      do {
        *param_1 = *param_1 ^ *param_2;
        param_2 = param_2 + 1;
        param_1 = param_1 + 1;
        iVar1 = iVar1 + 1;
      } while (iVar1 < *(int *)((int)this + 0x3cc));
    }
    return;
  }
  exception::exception(local_10,&this_0040f570);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_10,(ThrowInfo *)&pThrowInfo_0040d570);
}
