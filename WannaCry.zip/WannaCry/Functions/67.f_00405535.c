
void __cdecl FUN_00405535(uint *param_1,byte param_2)

{
  uint uVar1;
  
  uVar1 = *(uint *)(&DAT_0040d054 + (*param_1 & 0xff ^ (uint)param_2) * 4) ^ *param_1 >> 8;
  *param_1 = uVar1;
  uVar1 = ((uVar1 & 0xff) + param_1[1]) * 0x8088405 + 1;
  param_1[1] = uVar1;
  param_1[2] = *(uint *)(&DAT_0040d054 + (uVar1 >> 0x18 ^ param_1[2] & 0xff) * 4) ^ param_1[2] >> 8;
  return;
}
