
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0040170a(void)

{
  int iVar1;
  HMODULE hModule;
  
  iVar1 = FUN_00401a45();
  if (iVar1 != 0) {
    if (DAT_0040f878 != (FARPROC)0x0) {
      return 1;
    }
    hModule = LoadLibraryA(s_kernel32.dll_0040ebe8);
    if (hModule != (HMODULE)0x0) {
      DAT_0040f878 = GetProcAddress(hModule,s_CreateFileW_0040ebdc);
      DAT_0040f87c = GetProcAddress(hModule,s_WriteFile_0040ebd0);
      DAT_0040f880 = GetProcAddress(hModule,s_ReadFile_0040ebc4);
      DAT_0040f884 = GetProcAddress(hModule,s_MoveFileW_0040ebb8);
      DAT_0040f888 = GetProcAddress(hModule,s_MoveFileExW_0040ebac);
      DAT_0040f88c = GetProcAddress(hModule,s_DeleteFileW_0040eba0);
      _DAT_0040f890 = GetProcAddress(hModule,s_CloseHandle_0040eb94);
      if ((((DAT_0040f878 != (FARPROC)0x0) && (DAT_0040f87c != (FARPROC)0x0)) &&
          (DAT_0040f880 != (FARPROC)0x0)) &&
         (((DAT_0040f884 != (FARPROC)0x0 && (DAT_0040f888 != (FARPROC)0x0)) &&
          ((DAT_0040f88c != (FARPROC)0x0 && (_DAT_0040f890 != (FARPROC)0x0)))))) {
        return 1;
      }
    }
  }
  return 0;
}
