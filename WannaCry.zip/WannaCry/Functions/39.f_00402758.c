
bool __cdecl FUN_00402758(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  ushort *puVar5;
  bool bVar6;
  
  iVar1 = param_1[1];
  if (*(int *)(*param_1 + 0xa4) == 0) {
    bVar6 = param_2 == 0;
  }
  else {
    piVar3 = (int *)(*(int *)(*param_1 + 0xa0) + iVar1);
    iVar2 = *piVar3;
    while (iVar2 != 0) {
      param_1 = (int *)0x0;
      puVar5 = (ushort *)(piVar3 + 2);
      if ((piVar3[1] - 8U & 0xfffffffe) != 0) {
        do {
          if ((*puVar5 & 0xf000) == 0x3000) {
            piVar4 = (int *)((*puVar5 & 0xfff) + iVar2 + iVar1);
            *piVar4 = *piVar4 + param_2;
          }
          param_1 = (int *)((int)param_1 + 1);
          puVar5 = puVar5 + 1;
        } while (param_1 < (int *)(piVar3[1] - 8U >> 1));
      }
      piVar3 = (int *)((int)piVar3 + piVar3[1]);
      iVar2 = *piVar3;
    }
    bVar6 = true;
  }
  return bVar6;
}
