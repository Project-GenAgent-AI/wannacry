
undefined4 __cdecl FUN_0040671d(byte *param_1,byte *param_2)

{
  byte *pbVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 *_Memory;
  void *pvVar4;
  undefined4 uVar5;
  int local_10;
  int local_c;
  int local_8;
  
  pbVar1 = param_1;
  if ((param_1 == (byte *)0x0) || (*(int *)(param_1 + 0x18) == 0)) {
    uVar5 = 0xffffff9a;
  }
  else {
    if (*(int *)(param_1 + 0x7c) != 0) {
      FUN_00406a97((int)param_1);
    }
    iVar3 = FUN_0040657a((undefined4 *)param_1,&local_10,&local_8,&local_c);
    if (iVar3 == 0) {
      _Memory = (undefined4 *)malloc(0x84);
      if (_Memory != (undefined4 *)0x0) {
        pvVar4 = malloc(0x4000);
        *_Memory = pvVar4;
        _Memory[0x11] = local_8;
        _Memory[0x12] = local_c;
        _Memory[0x13] = 0;
        if (pvVar4 != (void *)0x0) {
          _Memory[0x10] = 0;
          iVar3 = *(int *)(param_1 + 0x34);
          _Memory[0x15] = *(undefined4 *)(param_1 + 0x3c);
          _Memory[0x14] = 0;
          _Memory[0x19] = *(undefined4 *)(param_1 + 0x34);
          _Memory[0x18] = *(undefined4 *)param_1;
          _Memory[0x1a] = *(undefined4 *)(param_1 + 0xc);
          _Memory[6] = 0;
          if (iVar3 != 0) {
            _Memory[9] = 0;
            _Memory[10] = 0;
            _Memory[0xb] = 0;
            iVar3 = FUN_00405777((int)(_Memory + 1));
            if (iVar3 == 0) {
              _Memory[0x10] = 1;
            }
          }
          _Memory[0x16] = *(undefined4 *)(param_1 + 0x40);
          _Memory[0x17] = *(undefined4 *)(param_1 + 0x44);
          *(byte *)(_Memory + 0x1b) = param_1[0x30] & 1;
          if ((*(uint *)(param_1 + 0x30) >> 3 & 1) == 0) {
            uVar2 = (undefined1)((uint)*(undefined4 *)(param_1 + 0x3c) >> 0x18);
          }
          else {
            uVar2 = (undefined1)((uint)*(undefined4 *)(param_1 + 0x38) >> 8);
          }
          *(undefined1 *)(_Memory + 0x20) = uVar2;
          _Memory[0x1d] = 0x23456789;
          _Memory[0x1f] = -(uint)(*(char *)(_Memory + 0x1b) != '\0') & 0xc;
          _Memory[0x1c] = 0x12345678;
          _Memory[0x1e] = 0x34567890;
          param_1 = param_2;
          if (param_2 != (byte *)0x0) {
            do {
              if (*param_1 == 0) break;
              FUN_00405535(_Memory + 0x1c,*param_1);
              param_1 = param_1 + 1;
            } while (param_1 != (byte *)0x0);
          }
          iVar3 = *(int *)(pbVar1 + 0x78);
          _Memory[2] = 0;
          _Memory[0xf] = iVar3 + 0x1e + local_10;
          *(undefined4 **)(pbVar1 + 0x7c) = _Memory;
          return 0;
        }
        free(_Memory);
      }
      uVar5 = 0xffffff98;
    }
    else {
      uVar5 = 0xffffff99;
    }
  }
  return uVar5;
}
