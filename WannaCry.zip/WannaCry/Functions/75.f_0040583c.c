
uint __cdecl FUN_0040583c(int *param_1,uint param_2)

{
  byte bVar1;
  undefined4 *puVar2;
  uint uVar3;
  undefined4 uVar4;
  
  if (((param_1 == (int *)0x0) || (puVar2 = (undefined4 *)param_1[7], puVar2 == (undefined4 *)0x0))
     || (*param_1 == 0)) {
LAB_00405b60:
    return 0xfffffffe;
  }
  uVar3 = 0xfffffffb;
  if (param_2 == 4) {
    param_2 = 0xfffffffb;
  }
  else {
    param_2 = 0;
  }
  uVar4 = *puVar2;
LAB_00405878:
  switch(uVar4) {
  case 0:
    if (param_1[1] == 0) {
      return uVar3;
    }
    param_1[2] = param_1[2] + 1;
    param_1[1] = param_1[1] + -1;
    puVar2[1] = (uint)*(byte *)*param_1;
    puVar2 = (undefined4 *)param_1[7];
    uVar4 = puVar2[1];
    *param_1 = *param_1 + 1;
    if (((byte)uVar4 & 0xf) == 8) {
      if (((uint)puVar2[1] >> 4) + 8 <= (uint)puVar2[4]) {
        *puVar2 = 1;
        uVar3 = param_2;
        goto switchD_00405880_caseD_1;
      }
      *puVar2 = 0xd;
      param_1[6] = (int)s_invalid_window_size_0040f7e8;
    }
    else {
      *puVar2 = 0xd;
      param_1[6] = (int)s_unknown_compression_method_0040f7fc;
    }
    goto LAB_00405a73;
  case 1:
switchD_00405880_caseD_1:
    if (param_1[1] == 0) {
      return uVar3;
    }
    param_1[2] = param_1[2] + 1;
    param_1[1] = param_1[1] + -1;
    puVar2 = (undefined4 *)param_1[7];
    bVar1 = *(byte *)*param_1;
    *param_1 = (int)((byte *)*param_1 + 1);
    if ((puVar2[1] * 0x100 + (uint)bVar1) % 0x1f == 0) {
      if ((bVar1 & 0x20) != 0) {
        *(undefined4 *)param_1[7] = 2;
        uVar3 = param_2;
        goto switchD_00405880_caseD_2;
      }
      *puVar2 = 7;
      uVar3 = param_2;
    }
    else {
      *puVar2 = 0xd;
      param_1[6] = (int)s_incorrect_header_check_0040f7d0;
      *(undefined4 *)(param_1[7] + 4) = 5;
      uVar3 = param_2;
    }
    break;
  case 2:
switchD_00405880_caseD_2:
    if (param_1[1] == 0) {
      return uVar3;
    }
    param_1[2] = param_1[2] + 1;
    param_1[1] = param_1[1] + -1;
    *(uint *)(param_1[7] + 8) = (uint)*(byte *)*param_1 << 0x18;
    *param_1 = *param_1 + 1;
    *(undefined4 *)param_1[7] = 3;
    uVar3 = param_2;
  case 3:
    goto switchD_00405880_caseD_3;
  case 4:
    goto switchD_00405880_caseD_4;
  case 5:
    goto switchD_00405880_caseD_5;
  case 6:
    *(undefined4 *)param_1[7] = 0xd;
    param_1[6] = (int)s_need_dictionary_0040f608;
    *(undefined4 *)(param_1[7] + 4) = 0;
    return 0xfffffffe;
  case 7:
    uVar3 = FUN_004043b6((uint *)puVar2[5],param_1,uVar3);
    if (uVar3 == 0xfffffffd) {
      *(undefined4 *)param_1[7] = 0xd;
      *(undefined4 *)(param_1[7] + 4) = 0;
      uVar3 = 0xfffffffd;
    }
    else {
      if (uVar3 == 0) {
        uVar3 = param_2;
      }
      if (uVar3 != 1) {
        return uVar3;
      }
      FUN_004042c0(*(int **)(param_1[7] + 0x14),(int)param_1,(int *)(param_1[7] + 4));
      puVar2 = (undefined4 *)param_1[7];
      if (puVar2[3] == 0) {
        *puVar2 = 8;
        uVar3 = param_2;
        goto switchD_00405880_caseD_8;
      }
      *puVar2 = 0xc;
      uVar3 = param_2;
    }
    break;
  case 8:
switchD_00405880_caseD_8:
    if (param_1[1] == 0) {
      return uVar3;
    }
    param_1[2] = param_1[2] + 1;
    param_1[1] = param_1[1] + -1;
    *(uint *)(param_1[7] + 8) = (uint)*(byte *)*param_1 << 0x18;
    *param_1 = *param_1 + 1;
    *(undefined4 *)param_1[7] = 9;
    uVar3 = param_2;
  case 9:
    if (param_1[1] == 0) {
      return uVar3;
    }
    param_1[2] = param_1[2] + 1;
    param_1[1] = param_1[1] + -1;
    *(int *)(param_1[7] + 8) = *(int *)(param_1[7] + 8) + (uint)*(byte *)*param_1 * 0x10000;
    *param_1 = *param_1 + 1;
    *(undefined4 *)param_1[7] = 10;
    uVar3 = param_2;
  case 10:
    goto switchD_00405880_caseD_a;
  case 0xb:
    goto switchD_00405880_caseD_b;
  case 0xc:
    goto LAB_00405b60;
  case 0xd:
    return 0xfffffffd;
  default:
    goto LAB_00405b60;
  }
LAB_00405a7d:
  puVar2 = (undefined4 *)param_1[7];
  uVar4 = *puVar2;
  goto LAB_00405878;
switchD_00405880_caseD_a:
  if (param_1[1] == 0) {
    return uVar3;
  }
  param_1[2] = param_1[2] + 1;
  param_1[1] = param_1[1] + -1;
  *(int *)(param_1[7] + 8) = *(int *)(param_1[7] + 8) + (uint)*(byte *)*param_1 * 0x100;
  *param_1 = *param_1 + 1;
  *(undefined4 *)param_1[7] = 0xb;
  uVar3 = param_2;
switchD_00405880_caseD_b:
  if (param_1[1] == 0) {
    return uVar3;
  }
  param_1[2] = param_1[2] + 1;
  param_1[1] = param_1[1] + -1;
  *(int *)(param_1[7] + 8) = *(int *)(param_1[7] + 8) + (uint)*(byte *)*param_1;
  puVar2 = (undefined4 *)param_1[7];
  *param_1 = *param_1 + 1;
  if (puVar2[1] == puVar2[2]) {
    *(undefined4 *)param_1[7] = 0xc;
LAB_00405b60:
    return 1;
  }
  *puVar2 = 0xd;
  param_1[6] = (int)s_incorrect_data_check_0040f7b8;
LAB_00405a73:
  *(undefined4 *)(param_1[7] + 4) = 5;
  uVar3 = param_2;
  goto LAB_00405a7d;
switchD_00405880_caseD_3:
  if (param_1[1] == 0) {
    return uVar3;
  }
  param_1[2] = param_1[2] + 1;
  param_1[1] = param_1[1] + -1;
  *(int *)(param_1[7] + 8) = *(int *)(param_1[7] + 8) + (uint)*(byte *)*param_1 * 0x10000;
  *param_1 = *param_1 + 1;
  *(undefined4 *)param_1[7] = 4;
  uVar3 = param_2;
switchD_00405880_caseD_4:
  if (param_1[1] == 0) {
    return uVar3;
  }
  param_1[2] = param_1[2] + 1;
  param_1[1] = param_1[1] + -1;
  *(int *)(param_1[7] + 8) = *(int *)(param_1[7] + 8) + (uint)*(byte *)*param_1 * 0x100;
  *param_1 = *param_1 + 1;
  *(undefined4 *)param_1[7] = 5;
  uVar3 = param_2;
switchD_00405880_caseD_5:
  if (param_1[1] != 0) {
    param_1[2] = param_1[2] + 1;
    param_1[1] = param_1[1] + -1;
    *(int *)(param_1[7] + 8) = *(int *)(param_1[7] + 8) + (uint)*(byte *)*param_1;
    *param_1 = *param_1 + 1;
    param_1[0xc] = ((undefined4 *)param_1[7])[2];
    *(undefined4 *)param_1[7] = 6;
    return 2;
  }
  return uVar3;
}
