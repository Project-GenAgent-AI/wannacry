
void __cdecl FUN_004075c4(int *param_1,int param_2,undefined4 *param_3)

{
  *param_3 = 0;
  *(undefined1 *)(param_3 + 1) = 0;
  param_3[0x4a] = 0;
  if (param_1 == (int *)0x0) {
    DAT_0040f938 = 0x10000;
  }
  else if (*param_1 == 1) {
    DAT_0040f938 = FUN_00406c40((void *)param_1[1],param_2,param_3);
  }
  else {
    DAT_0040f938 = 0x80000;
  }
  return;
}
