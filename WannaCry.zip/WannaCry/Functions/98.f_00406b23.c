
_FILETIME __cdecl FUN_00406b23(uint param_1,uint param_2)

{
  SYSTEMTIME local_1c;
  _FILETIME local_c;
  
  local_1c.wMilliseconds = 0;
  local_1c.wYear = ((ushort)param_1 >> 9) + 0x7bc;
  local_1c.wDay = (ushort)param_1 & 0x1f;
  local_1c.wMonth = (ushort)(param_1 >> 5) & 0xf;
  local_1c.wHour = (ushort)param_2 >> 0xb;
  local_1c.wSecond = (WORD)((param_2 & 0x1f) << 1);
  local_1c.wMinute = (ushort)(param_2 >> 5) & 0x3f;
  SystemTimeToFileTime(&local_1c,&local_c);
  return local_c;
}
