
undefined4 __cdecl
FUN_00405122(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  *param_1 = 9;
  *param_2 = 5;
  *param_3 = &DAT_0040bcf0;
  *param_4 = &DAT_0040ccf0;
  return 0;
}
