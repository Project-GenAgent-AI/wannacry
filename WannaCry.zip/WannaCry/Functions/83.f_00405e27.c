
void __cdecl FUN_00405e27(char *param_1,int *param_2)

{
  uint uVar1;
  int iVar2;
  uint local_8;
  
  iVar2 = FUN_00405def(param_1,&local_8);
  uVar1 = local_8;
  if ((iVar2 == 0) && (iVar2 = FUN_00405def(param_1,&local_8), iVar2 == 0)) {
    *param_2 = local_8 * 0x100 + uVar1;
    return;
  }
  *param_2 = 0;
  return;
}
