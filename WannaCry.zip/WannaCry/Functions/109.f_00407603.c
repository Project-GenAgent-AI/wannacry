
void __cdecl FUN_00407603(int *param_1,char *param_2,char *param_3,uint param_4,int param_5)

{
  if (param_1 == (int *)0x0) {
    DAT_0040f938 = 0x10000;
  }
  else if (*param_1 == 1) {
    DAT_0040f938 = FUN_00407136((void *)param_1[1],param_2,param_3,param_4,param_5);
  }
  else {
    DAT_0040f938 = 0x80000;
  }
  return;
}
