
int __cdecl
FUN_0040501f(uint param_1,uint param_2,int *param_3,uint *param_4,uint *param_5,int *param_6,
            int *param_7,int param_8,int param_9)

{
  uint *puVar1;
  int iVar2;
  uint local_8;
  
  local_8 = 0;
  puVar1 = (uint *)(**(code **)(param_9 + 0x20))(*(undefined4 *)(param_9 + 0x28),0x120,4);
  if (puVar1 == (uint *)0x0) {
    return -4;
  }
  iVar2 = FUN_00404c19(param_3,param_1,0x101,0x40ce6c,0x40cee8,param_6,param_4,param_8,&local_8,
                       puVar1);
  if (iVar2 == 0) {
    if (*param_4 == 0) goto LAB_00405104;
    iVar2 = FUN_00404c19(param_3 + param_1,param_2,0,0x40cf64,0x40cfdc,param_7,param_5,param_8,
                         &local_8,puVar1);
    if (iVar2 == 0) {
      if ((*param_5 != 0) || (param_1 < 0x102)) {
        iVar2 = 0;
        goto LAB_00405110;
      }
LAB_004050e8:
      *(char **)(param_9 + 0x18) = s_empty_distance_tree_with_lengths_0040f750;
    }
    else {
      if (iVar2 == -3) {
        *(char **)(param_9 + 0x18) = s_oversubscribed_distance_tree_0040f790;
        goto LAB_00405110;
      }
      if (iVar2 != -5) {
        if (iVar2 == -4) goto LAB_00405110;
        goto LAB_004050e8;
      }
      *(char **)(param_9 + 0x18) = s_incomplete_distance_tree_0040f774;
    }
  }
  else {
    if (iVar2 == -3) {
      *(char **)(param_9 + 0x18) = s_oversubscribed_literal/length_tr_0040f72c;
      goto LAB_00405110;
    }
    if (iVar2 == -4) goto LAB_00405110;
LAB_00405104:
    *(char **)(param_9 + 0x18) = s_incomplete_literal/length_tree_0040f70c;
  }
  iVar2 = -3;
LAB_00405110:
  (**(code **)(param_9 + 0x24))(*(undefined4 *)(param_9 + 0x28),puVar1);
  return iVar2;
}
