
undefined4 * FUN_004012fd(void)

{
  undefined4 *extraout_ECX;
  int unaff_EBP;
  
  FUN_004076c8();
  *(undefined4 **)(unaff_EBP + -0x10) = extraout_ECX;
  FUN_004017dd(extraout_ECX + 1);
  *(undefined4 *)(unaff_EBP + -4) = 0;
  FUN_004017dd(extraout_ECX + 0xb);
  *(undefined1 *)(unaff_EBP + -4) = 1;
  FUN_00402a46(extraout_ECX + 0x15);
  ExceptionList = *(void **)(unaff_EBP + -0xc);
  extraout_ECX[0x132] = 0;
  extraout_ECX[0x133] = 0;
  extraout_ECX[0x134] = 0;
  extraout_ECX[0x135] = 0;
  *extraout_ECX = &PTR_FUN_004081d8;
  return extraout_ECX;
}
