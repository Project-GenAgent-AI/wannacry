
undefined4 __fastcall FUN_004018b9(int param_1)

{
  if (*(int *)(param_1 + 8) != 0) {
    (*DAT_0040f89c)(*(int *)(param_1 + 8));
    *(undefined4 *)(param_1 + 8) = 0;
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    (*DAT_0040f89c)(*(int *)(param_1 + 0xc));
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  if (*(HCRYPTPROV *)(param_1 + 4) != 0) {
    CryptReleaseContext(*(HCRYPTPROV *)(param_1 + 4),0);
    *(undefined4 *)(param_1 + 4) = 0;
  }
  return 1;
}
