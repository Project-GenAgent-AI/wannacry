
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void entry(void)

{
  undefined4 *puVar1;
  byte *pbVar2;
  char **local_74;
  _startupinfo local_70;
  int local_6c;
  char **local_68;
  int local_64;
  _STARTUPINFOA local_60;
  undefined1 *local_1c;
  void *pvStack_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 local_8;
  
  puStack_c = &DAT_0040d488;
  puStack_10 = &DAT_004076f4;
  pvStack_14 = ExceptionList;
  local_1c = &stack0xffffff78;
  local_8 = 0;
  ExceptionList = &pvStack_14;
  __set_app_type(2);
  _DAT_0040f94c = 0xffffffff;
  _DAT_0040f950 = 0xffffffff;
  puVar1 = (undefined4 *)__p__fmode();
  *puVar1 = DAT_0040f948;
  puVar1 = (undefined4 *)__p__commode();
  *puVar1 = DAT_0040f944;
  _DAT_0040f954 = *(undefined4 *)_adjust_fdiv_exref;
  FUN_0040793f();
  if (DAT_0040f870 == 0) {
    __setusermatherr(&LAB_0040793c);
  }
  FUN_0040792a();
  initterm(&DAT_0040e008,&DAT_0040e00c);
  local_70.newmode = DAT_0040f940;
  __getmainargs(&local_64,&local_74,&local_68,_DoWildCard_0040f93c,&local_70);
  initterm(&DAT_0040e000,&DAT_0040e004);
  pbVar2 = *(byte **)_acmdln_exref;
  if (*pbVar2 != 0x22) {
    do {
      if (*pbVar2 < 0x21) goto LAB_004078ad;
      pbVar2 = pbVar2 + 1;
    } while( true );
  }
  do {
    pbVar2 = pbVar2 + 1;
    if (*pbVar2 == 0) break;
  } while (*pbVar2 != 0x22);
  if (*pbVar2 != 0x22) goto LAB_004078ad;
  do {
    pbVar2 = pbVar2 + 1;
LAB_004078ad:
  } while ((*pbVar2 != 0) && (*pbVar2 < 0x21));
  local_60.dwFlags = 0;
  GetStartupInfoA(&local_60);
  GetModuleHandleA((LPCSTR)0x0);
  local_6c = FUN_00401fe7();
                    /* WARNING: Subroutine does not return */
  exit(local_6c);
}
