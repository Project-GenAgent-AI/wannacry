
void __fastcall FUN_00407572(int param_1)

{
  if (*(void **)(param_1 + 0x138) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x138));
  }
  *(undefined4 *)(param_1 + 0x138) = 0;
  if (*(void **)(param_1 + 0x13c) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x13c));
  }
  *(undefined4 *)(param_1 + 0x13c) = 0;
  return;
}
