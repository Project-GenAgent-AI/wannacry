
int __thiscall FUN_00407136(void *this,char *param_1,char *param_2,uint param_3,int param_4)

{
  char *pcVar1;
  undefined4 *puVar2;
  int iVar3;
  char cVar4;
  char *pcVar5;
  void *pvVar6;
  uint uVar7;
  BOOL BVar8;
  char *pcVar9;
  char *pcVar10;
  LPCSTR pCVar11;
  CHAR local_33c [260];
  undefined4 local_238 [66];
  uint local_130;
  FILETIME local_12c;
  FILETIME local_124;
  FILETIME local_11c [2];
  char local_10c [260];
  DWORD local_8;
  
  iVar3 = param_4;
  pcVar5 = param_1;
  if (param_4 == 3) {
    if (param_1 != *(char **)((int)this + 4)) {
      if (*(char **)((int)this + 4) != (char *)0xffffffff) {
                    /* WARNING: Load size is inaccurate */
        FUN_00406a97(*this);
      }
                    /* WARNING: Load size is inaccurate */
      puVar2 = *this;
      *(undefined4 *)((int)this + 4) = 0xffffffff;
      if ((int)puVar2[1] <= (int)pcVar5) {
        return 0x10000;
      }
      if ((int)pcVar5 < (int)puVar2[4]) {
        FUN_004064e2(puVar2);
      }
                    /* WARNING: Load size is inaccurate */
      while ((int)(*this)[4] < (int)pcVar5) {
        FUN_00406520(*this);
      }
                    /* WARNING: Load size is inaccurate */
      FUN_0040671d(*this,*(byte **)((int)this + 0x138));
      *(char **)((int)this + 4) = pcVar5;
    }
                    /* WARNING: Load size is inaccurate */
    uVar7 = FUN_00406880(*this,(int)param_2,param_3,(undefined1 *)((int)&param_1 + 3));
    if ((int)uVar7 < 1) {
                    /* WARNING: Load size is inaccurate */
      FUN_00406a97(*this);
      *(undefined4 *)((int)this + 4) = 0xffffffff;
    }
    if (param_1._3_1_ != '\0') {
      return 0;
    }
    if ((int)uVar7 < 1) {
      return ((uVar7 != 0xffffff96) - 1 & 0xfb001000) + 0x5000000;
    }
    return 0x600;
  }
  if ((param_4 != 2) && (param_4 != 1)) {
    return 0x10000;
  }
  if (*(int *)((int)this + 4) != -1) {
                    /* WARNING: Load size is inaccurate */
    FUN_00406a97(*this);
  }
  pcVar5 = param_1;
                    /* WARNING: Load size is inaccurate */
  puVar2 = *this;
  *(undefined4 *)((int)this + 4) = 0xffffffff;
  if ((int)puVar2[1] <= (int)param_1) {
    return 0x10000;
  }
  if ((int)param_1 < (int)puVar2[4]) {
    FUN_004064e2(puVar2);
  }
                    /* WARNING: Load size is inaccurate */
  while ((int)(*this)[4] < (int)pcVar5) {
    FUN_00406520(*this);
  }
  FUN_00406c40(this,(int)pcVar5,local_238);
  pcVar5 = param_2;
  if ((local_130 & 0x10) != 0) {
    if (iVar3 == 1) {
      return 0;
    }
    cVar4 = *param_2;
    if (((cVar4 == '/') || (cVar4 == '\\')) || ((cVar4 != '\0' && (param_2[1] == ':')))) {
      pCVar11 = (LPCSTR)0x0;
    }
    else {
      pCVar11 = (LPCSTR)((int)this + 0x140);
    }
    FUN_00407070(pCVar11,param_2);
    return 0;
  }
  if (iVar3 == 1) goto LAB_00407331;
  cVar4 = *param_2;
  pcVar9 = param_2;
  pcVar10 = param_2;
  while (cVar4 != '\0') {
    if ((cVar4 == '/') || (cVar4 == '\\')) {
      pcVar10 = pcVar9 + 1;
    }
    pcVar1 = pcVar9 + 1;
    pcVar9 = pcVar9 + 1;
    cVar4 = *pcVar1;
  }
  strcpy(local_10c,param_2);
  if (pcVar10 == pcVar5) {
    local_10c[0] = '\0';
LAB_004072e1:
    wsprintfA(local_33c,s_%s%s%s_0040f848,(LPCSTR)((int)this + 0x140),local_10c,pcVar10);
    FUN_00407070((LPCSTR)((int)this + 0x140),local_10c);
  }
  else {
    pcVar10[(int)(local_10c + -(int)pcVar5)] = '\0';
    if (((local_10c[0] != '/') && (local_10c[0] != '\\')) &&
       ((local_10c[0] == '\0' || (local_10c[1] != ':')))) goto LAB_004072e1;
    wsprintfA(local_33c,(LPCSTR)&param_2_0040f840,local_10c,pcVar10);
    FUN_00407070((LPCSTR)0x0,local_10c);
  }
  pcVar5 = (char *)CreateFileA(local_33c,0x40000000,0,(LPSECURITY_ATTRIBUTES)0x0,2,local_130,
                               (HANDLE)0x0);
LAB_00407331:
  if (pcVar5 == (char *)0xffffffff) {
    return 0x200;
  }
                    /* WARNING: Load size is inaccurate */
  param_1 = pcVar5;
  FUN_0040671d(*this,*(byte **)((int)this + 0x138));
  if (*(int *)((int)this + 0x13c) == 0) {
    pvVar6 = operator_new(0x4000);
    *(void **)((int)this + 0x13c) = pvVar6;
  }
  param_3 = 0;
  do {
                    /* WARNING: Load size is inaccurate */
    uVar7 = FUN_00406880(*this,*(int *)((int)this + 0x13c),0x4000,(undefined1 *)((int)&param_2 + 3))
    ;
    if (uVar7 == 0xffffff96) {
      param_3 = 0x1000;
      goto LAB_0040745a;
    }
    if ((int)uVar7 < 0) break;
    if ((0 < (int)uVar7) &&
       (BVar8 = WriteFile(param_1,*(LPCVOID *)((int)this + 0x13c),uVar7,&local_8,(LPOVERLAPPED)0x0),
       BVar8 == 0)) {
      param_3 = 0x400;
      goto LAB_0040745a;
    }
    if (param_2._3_1_ != '\0') {
      SetFileTime(param_1,&local_124,&local_12c,local_11c);
      goto LAB_0040745a;
    }
  } while (uVar7 != 0);
  param_3 = 0x5000000;
LAB_0040745a:
  if (param_4 != 1) {
    CloseHandle(param_1);
  }
                    /* WARNING: Load size is inaccurate */
  FUN_00406a97(*this);
  return param_3;
}
