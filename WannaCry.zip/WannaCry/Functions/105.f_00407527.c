
undefined4 * __thiscall FUN_00407527(void *this,char *param_1)

{
  size_t sVar1;
  char *_Dest;
  
  *(undefined4 *)((int)this + 4) = 0xffffffff;
  *(undefined4 *)((int)this + 0x134) = 0xffffffff;
  *(undefined4 *)this = 0;
  *(undefined4 *)((int)this + 0x138) = 0;
  *(undefined4 *)((int)this + 0x13c) = 0;
  if (param_1 != (char *)0x0) {
    sVar1 = strlen(param_1);
    _Dest = (char *)operator_new(sVar1 + 1);
    *(char **)((int)this + 0x138) = _Dest;
    strcpy(_Dest,param_1);
  }
  return (undefined4 *)this;
}
