
undefined4 __cdecl FUN_00402470(int param_1,uint param_2,int param_3,int *param_4)

{
  size_t *psVar1;
  int iVar2;
  size_t sVar3;
  int iVar4;
  size_t *psVar5;
  int local_8;
  
  local_8 = 0;
  iVar2 = param_4[1];
  iVar4 = *param_4;
  psVar1 = (size_t *)((uint)*(ushort *)(iVar4 + 0x14) + iVar4);
  if (*(short *)(iVar4 + 6) != 0) {
    do {
      psVar5 = psVar1 + 10;
      if (*psVar5 == 0) {
        sVar3 = *(size_t *)(param_3 + 0x38);
        if (0 < (int)sVar3) {
          iVar4 = (*(code *)param_4[7])(iVar2 + psVar1[9],sVar3,0x1000,4,param_4[0xc]);
          if (iVar4 == 0) {
            return 0;
          }
          psVar1[8] = iVar2 + psVar1[9];
          memset((void *)(iVar2 + psVar1[9]),0,sVar3);
        }
      }
      else {
        iVar4 = FUN_00402457(param_2,psVar1[0xb] + *psVar5);
        if ((iVar4 == 0) ||
           (iVar4 = (*(code *)param_4[7])(iVar2 + psVar1[9],*psVar5,0x1000,4,param_4[0xc]),
           iVar4 == 0)) {
          return 0;
        }
        sVar3 = psVar1[9];
        memcpy((void *)(iVar2 + sVar3),(void *)(psVar1[0xb] + param_1),*psVar5);
        psVar1[8] = iVar2 + sVar3;
      }
      local_8 = local_8 + 1;
      psVar1 = psVar5;
    } while (local_8 < (int)(uint)*(ushort *)(*param_4 + 6));
  }
  return 1;
}
