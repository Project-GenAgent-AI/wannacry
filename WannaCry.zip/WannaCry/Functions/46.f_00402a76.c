
void __thiscall FUN_00402a76(void *this,byte *param_1,uint *param_2,int param_3,byte *param_4)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  int iVar5;
  uint *puVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  undefined4 *puVar10;
  exception local_18 [20];
  
  if (param_1 == (byte *)0x0) {
    param_2 = (uint *)&DAT_0040f57c;
    exception::exception(local_18,(char **)&param_2);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_18,(ThrowInfo *)&pThrowInfo_0040d570);
  }
  if (((param_3 != 0x10) && (param_3 != 0x18)) && (param_3 != 0x20)) {
    param_2 = (uint *)&DAT_0040f57c;
    exception::exception(local_18,(char **)&param_2);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_18,(ThrowInfo *)&pThrowInfo_0040d570);
  }
  if (((param_4 != (byte *)0x10) && (param_4 != (byte *)0x18)) && (param_4 != (byte *)0x20)) {
    param_2 = (uint *)&DAT_0040f57c;
    exception::exception(local_18,(char **)&param_2);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_18,(ThrowInfo *)&pThrowInfo_0040d570);
  }
  *(byte **)((int)this + 0x3cc) = param_4;
  *(int *)((int)this + 0x3c8) = param_3;
  memcpy((void *)((int)this + 0x3d0),param_2,(size_t)param_4);
  memcpy((void *)((int)this + 0x3f0),param_2,*(size_t *)((int)this + 0x3cc));
  if (*(int *)((int)this + 0x3c8) == 0x10) {
    if (*(int *)((int)this + 0x3cc) == 0x10) {
      iVar3 = 10;
    }
    else {
      iVar3 = ((*(int *)((int)this + 0x3cc) != 0x18) - 1 & 0xfffffffe) + 0xe;
    }
  }
  else {
    if (*(int *)((int)this + 0x3c8) != 0x18) {
      *(undefined4 *)((int)this + 0x410) = 0xe;
      goto LAB_00402b9a;
    }
    iVar3 = ((*(int *)((int)this + 0x3cc) == 0x20) - 1 & 0xfffffffe) + 0xe;
  }
  *(int *)((int)this + 0x410) = iVar3;
LAB_00402b9a:
  iVar3 = *(int *)((int)this + 0x3cc) / 4;
  iVar8 = 0;
  if (-1 < *(int *)((int)this + 0x410)) {
    puVar7 = (undefined4 *)((int)this + 8);
    do {
      iVar5 = iVar3;
      puVar10 = puVar7;
      if (0 < iVar3) {
        for (; iVar5 != 0; iVar5 = iVar5 + -1) {
          *puVar10 = 0;
          puVar10 = puVar10 + 1;
        }
      }
      iVar8 = iVar8 + 1;
      puVar7 = puVar7 + 8;
    } while (iVar8 <= *(int *)((int)this + 0x410));
  }
  iVar8 = 0;
  if (-1 < *(int *)((int)this + 0x410)) {
    puVar7 = (undefined4 *)((int)this + 0x1e8);
    do {
      iVar5 = iVar3;
      puVar10 = puVar7;
      if (0 < iVar3) {
        for (; iVar5 != 0; iVar5 = iVar5 + -1) {
          *puVar10 = 0;
          puVar10 = puVar10 + 1;
        }
      }
      iVar8 = iVar8 + 1;
      puVar7 = puVar7 + 8;
    } while (iVar8 <= *(int *)((int)this + 0x410));
  }
  puVar4 = (uint *)(*(int *)((int)this + 0x3c8) / 4);
  iVar8 = (*(int *)((int)this + 0x410) + 1) * iVar3;
  puVar6 = (uint *)((int)this + 0x414);
  param_2 = puVar4;
  if (0 < (int)puVar4) {
    do {
      *puVar6 = (uint)*param_1 << 0x18;
      *puVar6 = *puVar6 | (uint)param_1[1] << 0x10;
      *puVar6 = *puVar6 | (uint)param_1[2] << 8;
      *puVar6 = *puVar6 | (uint)param_1[3];
      param_1 = param_1 + 4;
      puVar6 = puVar6 + 1;
      param_2 = (uint *)((int)param_2 + -1);
    } while (param_2 != (uint *)0x0);
  }
  param_2 = (uint *)0x0;
  if (0 < (int)puVar4) {
    puVar7 = (undefined4 *)((int)this + 0x414);
    do {
      if (iVar8 <= (int)param_2) goto LAB_00402e04;
      iVar5 = (int)param_2 / iVar3;
      iVar9 = (int)param_2 % iVar3;
      *(undefined4 *)((int)this + (iVar9 + iVar5 * 8) * 4 + 8) = *puVar7;
      param_2 = (uint *)((int)param_2 + 1);
      uVar1 = *puVar7;
      puVar7 = puVar7 + 1;
      *(undefined4 *)((int)this + (iVar9 + (*(int *)((int)this + 0x410) - iVar5) * 8) * 4 + 0x1e8) =
           uVar1;
    } while ((int)param_2 < (int)puVar4);
  }
  if ((int)param_2 < iVar8) {
    param_4 = &DAT_0040bbfc;
    do {
      uVar2 = *(uint *)((int)this + (int)puVar4 * 4 + 0x410);
      *(uint *)((int)this + 0x414) =
           *(uint *)((int)this + 0x414) ^
           CONCAT31(CONCAT21(CONCAT11((&DAT_004089fc)[uVar2 >> 0x10 & 0xff] ^ *param_4,
                                      (&DAT_004089fc)[uVar2 >> 8 & 0xff]),
                             (&DAT_004089fc)[uVar2 & 0xff]),(&DAT_004089fc)[uVar2 >> 0x18]);
      param_4 = param_4 + 1;
      if (puVar4 == (uint *)0x8) {
        puVar6 = (uint *)((int)this + 0x418);
        iVar5 = 3;
        do {
          *puVar6 = *puVar6 ^ puVar6[-1];
          puVar6 = puVar6 + 1;
          iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        uVar2 = *(uint *)((int)this + 0x420);
        puVar6 = (uint *)((int)this + 0x428);
        *(uint *)((int)this + 0x424) =
             *(uint *)((int)this + 0x424) ^
             CONCAT31(CONCAT21(CONCAT11((&DAT_004089fc)[uVar2 >> 0x18],
                                        (&DAT_004089fc)[uVar2 >> 0x10 & 0xff]),
                               (&DAT_004089fc)[uVar2 >> 8 & 0xff]),(&DAT_004089fc)[uVar2 & 0xff]);
        iVar5 = 3;
        do {
          *puVar6 = *puVar6 ^ puVar6[-1];
          puVar6 = puVar6 + 1;
          iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
      }
      else if (1 < (int)puVar4) {
        puVar6 = (uint *)((int)this + 0x418);
        iVar5 = (int)puVar4 + -1;
        do {
          *puVar6 = *puVar6 ^ puVar6[-1];
          puVar6 = puVar6 + 1;
          iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
      }
      param_1 = (byte *)0x0;
      if (0 < (int)puVar4) {
        puVar7 = (undefined4 *)((int)this + 0x414);
        do {
          if (iVar8 <= (int)param_2) goto LAB_00402e04;
          iVar5 = (int)param_2 / iVar3;
          iVar9 = (int)param_2 % iVar3;
          *(undefined4 *)((int)this + (iVar9 + iVar5 * 8) * 4 + 8) = *puVar7;
          param_1 = param_1 + 1;
          uVar1 = *puVar7;
          puVar7 = puVar7 + 1;
          param_2 = (uint *)((int)param_2 + 1);
          *(undefined4 *)
           ((int)this + (iVar9 + (*(int *)((int)this + 0x410) - iVar5) * 8) * 4 + 0x1e8) = uVar1;
        } while ((int)param_1 < (int)puVar4);
      }
    } while ((int)param_2 < iVar8);
  }
LAB_00402e04:
  param_4 = (byte *)0x1;
  if (1 < *(int *)((int)this + 0x410)) {
    param_2 = (uint *)((int)this + 0x208);
    do {
      iVar8 = iVar3;
      puVar6 = param_2;
      if (0 < iVar3) {
        do {
          uVar2 = *puVar6;
          *puVar6 = *(uint *)(&DAT_0040abfc + (uVar2 >> 0x18) * 4) ^
                    *(uint *)(&DAT_0040affc + (uVar2 >> 0x10 & 0xff) * 4) ^
                    *(uint *)(&DAT_0040b3fc + (uVar2 >> 8 & 0xff) * 4) ^
                    *(uint *)(&DAT_0040b7fc + (uVar2 & 0xff) * 4);
          iVar8 = iVar8 + -1;
          puVar6 = puVar6 + 1;
        } while (iVar8 != 0);
      }
      param_4 = param_4 + 1;
      param_2 = param_2 + 8;
    } while ((int)param_4 < *(int *)((int)this + 0x410));
  }
  *(undefined1 *)((int)this + 4) = 1;
  return;
}
