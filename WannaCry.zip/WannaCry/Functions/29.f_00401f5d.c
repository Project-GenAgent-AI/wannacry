
undefined4 FUN_00401f5d(void)

{
  int iVar1;
  undefined4 *puVar2;
  CHAR local_20c;
  undefined4 local_20b;
  
  local_20c = DAT_0040f910;
  puVar2 = &local_20b;
  for (iVar1 = 0x81; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  *(undefined2 *)puVar2 = 0;
  *(undefined1 *)((int)puVar2 + 2) = 0;
  GetFullPathNameA(s_tasksche.exe_0040f4d8,0x208,&local_20c,(LPSTR *)0x0);
  iVar1 = FUN_00401ce8(&local_20c);
  if ((iVar1 != 0) && (iVar1 = FUN_00401eff(0x3c), iVar1 != 0)) {
    return 1;
  }
  iVar1 = FUN_00401064(&local_20c,0,(LPDWORD)0x0);
  if ((iVar1 != 0) && (iVar1 = FUN_00401eff(0x3c), iVar1 != 0)) {
    return 1;
  }
  return 0;
}
