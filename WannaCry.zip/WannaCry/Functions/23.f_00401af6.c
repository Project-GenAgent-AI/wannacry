
undefined4 __cdecl FUN_00401af6(LPCWSTR param_1,LPCWSTR param_2,wchar_t *param_3)

{
  BOOL BVar1;
  DWORD DVar2;
  
  CreateDirectoryW(param_1,(LPSECURITY_ATTRIBUTES)0x0);
  BVar1 = SetCurrentDirectoryW(param_1);
  if (BVar1 != 0) {
    CreateDirectoryW(param_2,(LPSECURITY_ATTRIBUTES)0x0);
    BVar1 = SetCurrentDirectoryW(param_2);
    if (BVar1 != 0) {
      DVar2 = GetFileAttributesW(param_2);
      SetFileAttributesW(param_2,DVar2 | 6);
      if (param_3 != (wchar_t *)0x0) {
        swprintf(param_3,0x40eb88,param_1);
      }
      return 1;
    }
  }
  return 0;
}
