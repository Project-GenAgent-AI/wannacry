
undefined4 __cdecl FUN_00405cc7(char *param_1)

{
  if ((*param_1 != '\0') && (param_1[8] != '\0')) {
    return 1;
  }
  return 0;
}
