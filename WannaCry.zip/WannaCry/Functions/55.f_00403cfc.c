
void __cdecl FUN_00403cfc(uint param_1,int *param_2,int param_3)

{
  int *piVar1;
  byte bVar2;
  int *piVar3;
  undefined1 *puVar4;
  int iVar5;
  uint uVar6;
  int *piVar7;
  uint uVar8;
  undefined1 *puVar9;
  undefined1 *puVar10;
  byte *local_18;
  undefined1 *local_14;
  undefined1 *local_10;
  uint local_c;
  byte *local_8;
  
  piVar7 = param_2;
  uVar6 = param_1;
  local_8 = (byte *)*param_2;
  local_c = param_2[1];
  puVar10 = *(undefined1 **)(param_1 + 0x34);
  param_2 = *(int **)(param_1 + 0x20);
  piVar3 = *(int **)(param_1 + 4);
  if (puVar10 < *(undefined1 **)(param_1 + 0x30)) {
    local_10 = *(undefined1 **)(param_1 + 0x30) + (-1 - (int)puVar10);
    param_1 = *(uint *)(param_1 + 0x1c);
  }
  else {
    local_10 = (undefined1 *)(*(int *)(param_1 + 0x2c) - (int)puVar10);
    param_1 = *(uint *)(param_1 + 0x1c);
  }
  do {
    switch(*piVar3) {
    case 0:
      if (((undefined1 *)0x101 < local_10) && (9 < local_c)) {
        *(int **)(uVar6 + 0x20) = param_2;
        *(uint *)(uVar6 + 0x1c) = param_1;
        piVar7[1] = local_c;
        iVar5 = *piVar7;
        *piVar7 = (int)local_8;
        piVar7[2] = (int)(local_8 + (piVar7[2] - iVar5));
        *(undefined1 **)(uVar6 + 0x34) = puVar10;
        param_3 = FUN_0040514d((uint)*(byte *)(piVar3 + 4),(uint)*(byte *)((int)piVar3 + 0x11),
                               piVar3[5],piVar3[6],uVar6,piVar7);
        local_8 = (byte *)*piVar7;
        local_c = piVar7[1];
        puVar10 = *(undefined1 **)(uVar6 + 0x34);
        param_2 = *(int **)(uVar6 + 0x20);
        param_1 = *(uint *)(uVar6 + 0x1c);
        if (puVar10 < *(undefined1 **)(uVar6 + 0x30)) {
          local_10 = *(undefined1 **)(uVar6 + 0x30) + (-1 - (int)puVar10);
        }
        else {
          local_10 = (undefined1 *)(*(int *)(uVar6 + 0x2c) - (int)puVar10);
        }
        if (param_3 != 0) {
          *piVar3 = (-(uint)(param_3 != 1) & 2) + 7;
          break;
        }
      }
      piVar3[3] = (uint)*(byte *)(piVar3 + 4);
      piVar3[2] = piVar3[5];
      *piVar3 = 1;
    case 1:
      for (; param_1 < (uint)piVar3[3]; param_1 = param_1 + 8) {
        if (local_c == 0) goto LAB_0040415f;
        param_3 = 0;
        local_c = local_c - 1;
        param_2 = (int *)((uint)param_2 | (uint)*local_8 << ((byte)param_1 & 0x1f));
        local_8 = local_8 + 1;
      }
      local_18 = (byte *)(piVar3[2] + (*(uint *)(&DAT_0040bca8 + piVar3[3] * 4) & (uint)param_2) * 8
                         );
      param_2 = (int *)((uint)param_2 >> (local_18[1] & 0x1f));
      param_1 = param_1 - local_18[1];
      bVar2 = *local_18;
      uVar8 = (uint)bVar2;
      if (uVar8 == 0) {
        iVar5 = *(int *)(local_18 + 4);
        *piVar3 = 6;
        piVar3[2] = iVar5;
      }
      else if ((bVar2 & 0x10) == 0) {
        if ((bVar2 & 0x40) == 0) {
LAB_00403f71:
          piVar3[3] = uVar8;
          piVar3[2] = (int)(local_18 + *(int *)(local_18 + 4) * 8);
        }
        else {
          if ((bVar2 & 0x20) == 0) {
            *piVar3 = 9;
            piVar7[6] = (int)s_invalid_literal/length_code_0040f630;
switchD_00403d47_caseD_9:
            param_3 = -3;
            *(int **)(uVar6 + 0x20) = param_2;
            *(uint *)(uVar6 + 0x1c) = param_1;
            piVar7[1] = local_c;
            iVar5 = *piVar7;
            *piVar7 = (int)local_8;
            piVar7[2] = (int)(local_8 + (piVar7[2] - iVar5));
            *(undefined1 **)(uVar6 + 0x34) = puVar10;
            goto LAB_00404278;
          }
          *piVar3 = 7;
        }
      }
      else {
        piVar3[2] = uVar8 & 0xf;
        piVar3[1] = *(int *)(local_18 + 4);
        *piVar3 = 2;
      }
      break;
    case 2:
      for (; param_1 < (uint)piVar3[2]; param_1 = param_1 + 8) {
        if (local_c == 0) goto LAB_0040415f;
        param_3 = 0;
        local_c = local_c - 1;
        param_2 = (int *)((uint)param_2 | (uint)*local_8 << ((byte)param_1 & 0x1f));
        local_8 = local_8 + 1;
      }
      uVar8 = *(uint *)(&DAT_0040bca8 + piVar3[2] * 4) & (uint)param_2;
      *piVar3 = 3;
      param_2 = (int *)((uint)param_2 >> ((byte)piVar3[2] & 0x1f));
      piVar3[1] = piVar3[1] + uVar8;
      param_1 = param_1 - piVar3[2];
      piVar3[3] = (uint)*(byte *)((int)piVar3 + 0x11);
      piVar3[2] = piVar3[6];
    case 3:
      for (; param_1 < (uint)piVar3[3]; param_1 = param_1 + 8) {
        if (local_c == 0) goto LAB_0040415f;
        param_3 = 0;
        local_c = local_c - 1;
        param_2 = (int *)((uint)param_2 | (uint)*local_8 << ((byte)param_1 & 0x1f));
        local_8 = local_8 + 1;
      }
      local_18 = (byte *)(piVar3[2] + (*(uint *)(&DAT_0040bca8 + piVar3[3] * 4) & (uint)param_2) * 8
                         );
      param_2 = (int *)((uint)param_2 >> (local_18[1] & 0x1f));
      param_1 = param_1 - local_18[1];
      bVar2 = *local_18;
      uVar8 = (uint)bVar2;
      if ((bVar2 & 0x10) == 0) {
        if ((bVar2 & 0x40) == 0) goto LAB_00403f71;
        *piVar3 = 9;
        piVar7[6] = (int)s_invalid_distance_code_0040f618;
        goto switchD_00403d47_caseD_9;
      }
      piVar3[2] = uVar8 & 0xf;
      piVar3[3] = *(int *)(local_18 + 4);
      *piVar3 = 4;
      break;
    case 4:
      for (; param_1 < (uint)piVar3[2]; param_1 = param_1 + 8) {
        if (local_c == 0) goto LAB_0040415f;
        param_3 = 0;
        local_c = local_c - 1;
        param_2 = (int *)((uint)param_2 | (uint)*local_8 << ((byte)param_1 & 0x1f));
        local_8 = local_8 + 1;
      }
      uVar8 = *(uint *)(&DAT_0040bca8 + piVar3[2] * 4) & (uint)param_2;
      *piVar3 = 5;
      param_2 = (int *)((uint)param_2 >> ((byte)piVar3[2] & 0x1f));
      piVar3[3] = piVar3[3] + uVar8;
      param_1 = param_1 - piVar3[2];
    case 5:
      local_14 = puVar10 + -piVar3[3];
      if (local_14 < *(undefined1 **)(uVar6 + 0x28)) {
        do {
          local_14 = local_14 + (*(int *)(uVar6 + 0x2c) - (int)*(undefined1 **)(uVar6 + 0x28));
        } while (local_14 < *(undefined1 **)(uVar6 + 0x28));
      }
      iVar5 = piVar3[1];
      while (iVar5 != 0) {
        puVar9 = puVar10;
        if (local_10 == (undefined1 *)0x0) {
          if (puVar10 == *(undefined1 **)(uVar6 + 0x2c)) {
            local_10 = *(undefined1 **)(uVar6 + 0x30);
            puVar9 = *(undefined1 **)(uVar6 + 0x28);
            if (local_10 != puVar9) {
              if (puVar9 < local_10) {
                local_10 = local_10 + (-1 - (int)puVar9);
              }
              else {
                local_10 = *(undefined1 **)(uVar6 + 0x2c) + -(int)puVar9;
              }
              puVar10 = puVar9;
              if (local_10 != (undefined1 *)0x0) goto LAB_00404090;
            }
          }
          *(undefined1 **)(uVar6 + 0x34) = puVar10;
          param_3 = FUN_00403bd6(uVar6,piVar7,param_3);
          puVar9 = *(undefined1 **)(uVar6 + 0x34);
          puVar10 = *(undefined1 **)(uVar6 + 0x30);
          if (puVar9 < puVar10) {
            local_10 = puVar10 + (-1 - (int)puVar9);
          }
          else {
            local_10 = (undefined1 *)(*(int *)(uVar6 + 0x2c) - (int)puVar9);
          }
          if ((puVar9 == *(undefined1 **)(uVar6 + 0x2c)) &&
             (puVar4 = *(undefined1 **)(uVar6 + 0x28), puVar10 != puVar4)) {
            puVar9 = puVar4;
            if (puVar4 < puVar10) {
              local_10 = puVar10 + (-1 - (int)puVar4);
            }
            else {
              local_10 = *(undefined1 **)(uVar6 + 0x2c) + -(int)puVar4;
            }
          }
          if (local_10 == (undefined1 *)0x0) goto LAB_004041b5;
        }
LAB_00404090:
        param_3 = 0;
        *puVar9 = *local_14;
        puVar10 = puVar9 + 1;
        local_14 = local_14 + 1;
        local_10 = local_10 + -1;
        if (local_14 == *(undefined1 **)(uVar6 + 0x2c)) {
          local_14 = *(undefined1 **)(uVar6 + 0x28);
        }
        piVar1 = piVar3 + 1;
        *piVar1 = *piVar1 + -1;
        iVar5 = *piVar1;
      }
LAB_00404157:
      *piVar3 = 0;
      break;
    case 6:
      puVar9 = puVar10;
      if (local_10 != (undefined1 *)0x0) {
LAB_00404149:
        param_3 = 0;
        *puVar9 = (char)piVar3[2];
        puVar10 = puVar9 + 1;
        local_10 = local_10 + -1;
        goto LAB_00404157;
      }
      if (puVar10 == *(undefined1 **)(uVar6 + 0x2c)) {
        local_10 = *(undefined1 **)(uVar6 + 0x30);
        puVar9 = *(undefined1 **)(uVar6 + 0x28);
        if (local_10 != puVar9) {
          if (puVar9 < local_10) {
            local_10 = local_10 + (-1 - (int)puVar9);
          }
          else {
            local_10 = *(undefined1 **)(uVar6 + 0x2c) + -(int)puVar9;
          }
          puVar10 = puVar9;
          if (local_10 != (undefined1 *)0x0) goto LAB_00404149;
        }
      }
      *(undefined1 **)(uVar6 + 0x34) = puVar10;
      param_3 = FUN_00403bd6(uVar6,piVar7,param_3);
      puVar9 = *(undefined1 **)(uVar6 + 0x34);
      puVar10 = *(undefined1 **)(uVar6 + 0x30);
      if (puVar9 < puVar10) {
        local_10 = puVar10 + (-1 - (int)puVar9);
      }
      else {
        local_10 = (undefined1 *)(*(int *)(uVar6 + 0x2c) - (int)puVar9);
      }
      if ((puVar9 == *(undefined1 **)(uVar6 + 0x2c)) &&
         (puVar4 = *(undefined1 **)(uVar6 + 0x28), puVar10 != puVar4)) {
        puVar9 = puVar4;
        if (puVar4 < puVar10) {
          local_10 = puVar10 + (-1 - (int)puVar4);
        }
        else {
          local_10 = *(undefined1 **)(uVar6 + 0x2c) + -(int)puVar4;
        }
      }
      if (local_10 != (undefined1 *)0x0) goto LAB_00404149;
LAB_004041b5:
      *(int **)(uVar6 + 0x20) = param_2;
      *(uint *)(uVar6 + 0x1c) = param_1;
      piVar7[1] = local_c;
      puVar10 = puVar9;
      goto LAB_004041c7;
    case 7:
      if (7 < param_1) {
        param_1 = param_1 - 8;
        local_c = local_c + 1;
        local_8 = local_8 + -1;
      }
      *(undefined1 **)(uVar6 + 0x34) = puVar10;
      param_3 = FUN_00403bd6(uVar6,piVar7,param_3);
      puVar10 = *(undefined1 **)(uVar6 + 0x34);
      if (*(undefined1 **)(uVar6 + 0x30) == puVar10) {
        *piVar3 = 8;
switchD_00403d47_caseD_8:
        param_3 = 1;
        *(int **)(uVar6 + 0x20) = param_2;
        *(uint *)(uVar6 + 0x1c) = param_1;
        piVar7[1] = local_c;
        iVar5 = *piVar7;
        *piVar7 = (int)local_8;
        piVar7[2] = (int)(local_8 + (piVar7[2] - iVar5));
        *(undefined1 **)(uVar6 + 0x34) = puVar10;
      }
      else {
        *(int **)(uVar6 + 0x20) = param_2;
        *(uint *)(uVar6 + 0x1c) = param_1;
        piVar7[1] = local_c;
        iVar5 = *piVar7;
        *piVar7 = (int)local_8;
        piVar7[2] = (int)(local_8 + (piVar7[2] - iVar5));
        *(undefined1 **)(uVar6 + 0x34) = puVar10;
      }
LAB_00404278:
      FUN_00403bd6(uVar6,piVar7,param_3);
      return;
    case 8:
      goto switchD_00403d47_caseD_8;
    case 9:
      goto switchD_00403d47_caseD_9;
    default:
      param_3 = -2;
      *(int **)(uVar6 + 0x20) = param_2;
      *(uint *)(uVar6 + 0x1c) = param_1;
      piVar7[1] = local_c;
      iVar5 = *piVar7;
      *piVar7 = (int)local_8;
      piVar7[2] = (int)(local_8 + (piVar7[2] - iVar5));
      *(undefined1 **)(uVar6 + 0x34) = puVar10;
      goto LAB_00404278;
    }
  } while( true );
LAB_0040415f:
  *(int **)(uVar6 + 0x20) = param_2;
  *(uint *)(uVar6 + 0x1c) = param_1;
  piVar7[1] = 0;
LAB_004041c7:
  iVar5 = *piVar7;
  *piVar7 = (int)local_8;
  piVar7[2] = (int)(local_8 + (piVar7[2] - iVar5));
  *(undefined1 **)(uVar6 + 0x34) = puVar10;
  goto LAB_00404278;
}
