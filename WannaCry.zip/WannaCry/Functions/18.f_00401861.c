
undefined4 __thiscall FUN_00401861(void *this,LPCSTR param_1)

{
  int iVar1;
  
  iVar1 = FUN_0040182c((int)this);
  if (iVar1 != 0) {
    if (param_1 == (LPCSTR)0x0) {
      iVar1 = (*DAT_0040f898)(*(undefined4 *)((int)this + 4),&DAT_0040ebf8,0x494,0,0,(int)this + 8);
    }
    else {
      iVar1 = FUN_004018f9(*(undefined4 *)((int)this + 4),(int)this + 8,param_1);
    }
    if (iVar1 != 0) {
      return 1;
    }
  }
  FUN_004018b9((int)this);
  return 0;
}

