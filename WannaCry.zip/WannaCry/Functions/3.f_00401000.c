
bool __cdecl FUN_00401000(void *param_1,int param_2)

{
  FILE *_File;
  size_t sVar1;
  bool bVar2;
  char *_Mode;
  
  if (param_2 == 0) {
    _Mode = &DAT_0040e018;
  }
  else {
    _Mode = &DAT_0040e01c;
  }
  _File = fopen(s_c.wnry_0040e010,_Mode);
  if (_File == (FILE *)0x0) {
    bVar2 = false;
  }
  else {
    if (param_2 == 0) {
      sVar1 = fwrite(param_1,0x30c,1,_File);
    }
    else {
      sVar1 = fread(param_1,0x30c,1,_File);
    }
    bVar2 = sVar1 != 0;
    fclose(_File);
  }
  return bVar2;
}
