
void __cdecl FUN_004021bd(short *param_1,uint param_2)

{
  FUN_004021e9(param_1,param_2,&LAB_0040216e,&LAB_00402185,0x402198,&LAB_004021a3,0x4021b2,0);
  return;
}
