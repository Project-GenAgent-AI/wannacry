
undefined4 __cdecl FUN_00405c9f(void *param_1)

{
  if (param_1 == (void *)0x0) {
    return 0xffffffff;
  }
  if (*(char *)((int)param_1 + 0x10) != '\0') {
    CloseHandle(*(HANDLE *)((int)param_1 + 4));
  }
  operator_delete(param_1);
  return 0;
}
