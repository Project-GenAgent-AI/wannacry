
undefined4 __cdecl FUN_004018f9(undefined4 param_1,undefined4 param_2,LPCSTR param_3)

{
  HANDLE hFile;
  DWORD dwBytes;
  HGLOBAL lpBuffer;
  BOOL BVar1;
  int iVar2;
  undefined4 uVar3;
  DWORD local_20 [3];
  void *local_14;
  undefined *puStack_10;
  undefined *puStack_c;
  undefined4 local_8;
  
  puStack_c = &DAT_004081f0;
  puStack_10 = &DAT_004076f4;
  local_14 = ExceptionList;
  uVar3 = 0;
  local_20[0] = 0;
  local_8 = 0;
  ExceptionList = &local_14;
  hFile = CreateFileA(param_3,0x80000000,1,(LPSECURITY_ATTRIBUTES)0x0,3,0,(HANDLE)0x0);
  if (hFile != (HANDLE)0xffffffff) {
    dwBytes = GetFileSize(hFile,(LPDWORD)0x0);
    if ((dwBytes != 0xffffffff) && (dwBytes < 0x19001)) {
      lpBuffer = GlobalAlloc(0,dwBytes);
      if (lpBuffer != (HGLOBAL)0x0) {
        BVar1 = ReadFile(hFile,lpBuffer,dwBytes,local_20,(LPOVERLAPPED)0x0);
        if (BVar1 != 0) {
          iVar2 = (*DAT_0040f898)(param_1,lpBuffer,local_20[0],0,0,param_2);
          if (iVar2 != 0) {
            uVar3 = 1;
          }
        }
      }
    }
  }
  local_unwind2(&local_14,0xffffffff);
  ExceptionList = local_14;
  return uVar3;
}
